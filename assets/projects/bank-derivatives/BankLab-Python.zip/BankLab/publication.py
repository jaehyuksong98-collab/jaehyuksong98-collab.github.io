"""Render the report and guides from verified numerical outputs with ReportLab."""
from model import *
from examples import rows as examples
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,Table,TableStyle,Image
from reportlab.lib.pagesizes import A4
from xml.sax.saxutils import escape
from PIL import Image as PILImage
ink='#173447'; teal='#0B6C6A'
story=[]
def para(txt,size=10,bold=False):
    style=ParagraphStyle('body',fontName='Helvetica-Bold' if bold else 'Helvetica',fontSize=size,leading=size*1.43,textColor=colors.HexColor(ink),spaceAfter=7)
    story.append(Paragraph(txt,style))
def title(kicker,name):
    if story: story.append(PageBreak())
    para(kicker.upper(),8,True);para(name,23,True)
def h(s):para(s,13,True)
def table(headers,rows,widths):
    def cell(x,head):
        return Paragraph(escape(str(x)),ParagraphStyle('cell',fontName='Helvetica-Bold' if head else 'Helvetica',fontSize=8.4,leading=11,textColor=colors.white if head else colors.HexColor(ink)))
    data=[[cell(v,True) for v in headers]]+[[cell(v,False) for v in r] for r in rows]
    t=Table(data,colWidths=[w*mm for w in widths],repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor(ink)),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#EDF4F3')]),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),5),('BOTTOMPADDING',(0,0),(-1,-1),5)]))
    story.extend([t,Spacer(1,9)])
def chart(name,w=155):
    file=ROOT/(name+'.png')
    with PILImage.open(file) as im: ratio=im.height/im.width
    story.append(Image(str(file),width=w*mm,height=w*mm*ratio))
def finish(name):
    doc=SimpleDocTemplate(str(ROOT/(name+'.pdf')),pagesize=A4,leftMargin=19*mm,rightMargin=19*mm,topMargin=15*mm,bottomMargin=16*mm,title=name.replace('_',' '))
    def footer(can,d):
        can.setFont('Helvetica',8);can.setFillColor(colors.HexColor(teal));can.drawString(19*mm,9*mm,'BANK DERIVATIVES LAB    /    SYNTHETIC CASE');can.drawRightString(191*mm,9*mm,str(d.page))
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    story.clear()
def fmt(x):return f'{x:,.3f}'
title('Acquisition finance  /  case report','Funding a US acquisition')
para('Fjord Instruments, a fictional euro-based buyer, signs a USD 100m purchase agreement on 1 January 2027. A USD 60m loan draws directly into escrow on 1 July. The buyer needs euros for the remaining USD 40m. The financing commitment and acquisition timetable determine how much FX to hedge.')
table(['Exposure','Decision at execution','Risk if assumptions change'],[['USD 40m payment','Buy USD forward or buy a European USD call.','A delayed or cancelled deal leaves the original hedge outstanding.'],['USD 60m debt','After closing, retain the floating coupon, pay fixed on a swap, or buy a 5% cap.','Refinancing removes the loan while the derivative retains its value.'],['Dealer obligations','Offset FX, rate and option trades in the market.','Different indices, credit terms and settlement times create residual exposure.']],[38,68,66])
h('Trade sequence')
para('At signing, confirm the debt currency, draw conditions and residual USD requirement. Markets records the EUR-per-USD quote and European exercise date. At the three-month review, revalue outstanding trades. At closing, settle the FX hedge, draw the loan and choose the debt hedge. Fix each six-month coupon at the start of its period and pay at the end. Repay the USD 60m bullet with the final coupon.')
h('Illustrative team responsibilities')
table(['Team','Decision or challenge'],[['Investment Banking','Tests acquisition affordability, timing, financing certainty and debt structure with the client.'],['Markets','Translates exposure into terms, quotes the client, confirms execution and rebalances hedges.'],['Treasury','Checks currencies and timing of funding, collateral calls, liquidity buffers and settlement lines.'],['Risk','Independently challenges curves, volatility, fixing status, stress losses, exposure and limits.']],[46,126])
para('Model all amounts at fair value. For a quote illustration only, add EUR 0.020m to the call premium. The difference is gross quoted markup. Hedge execution, funding, credit, capital and operating costs would be needed to estimate profit. All exhibits below exclude the markup.',9)
title('Client decision  /  acquisition FX','What the buyer pays in euros')
para(f'Spot is {S:.2f} EUR per USD. A higher number makes the target more expensive. With EUR and USD continuous zero rates of {eu:.0%} and {us:.0%}, the six-month forward is {K:.6f}, or {(K-S)*10000:.2f} points. Buying USD now and financing the purchase gives the same locked price. An at-forward-strike call costs EUR {premium:.3f}m today, equivalent to EUR {carry:.3f}m at close.')
table(['Expiry spot','Spot purchase','Forward cost','Call cost¹','Cancel forward²','Cancel call¹²'],[[f'{r[0]:.2f}',*[fmt(r[i]) for i in (1,4,5,6,7)]] for r in fxrows],[23,28,29,28,33,31])
para('EUR millions. ¹ Includes premium grown at the EUR funding rate. ² No acquisition payment. Positive means a cost and negative means cash benefit. Cash settlement plus buying USD at spot gives the same net cost as physical delivery at the locked price.',8)
chart('fx_cost',145)
h('When the date moves')
para(f'At month three, spot 0.88 gives the client forward MTM of EUR {midfx[0]:.3f}m and call MTM of EUR {midfx[1]:.3f}m. These are replacement values before settlement. An agreed unwind realizes them, with the call premium already paid.')
para(f'If closing slips three months and spot at the old expiry is 0.82, the forward costs EUR {-old_f:.3f}m to settle. The call expires worthless. A fresh three-month forward costs zero upfront and locks {roll:.6f}. Including financing of earlier cash, month-nine acquisition costs are EUR {delay[0]:.3f}m after the old forward or EUR {delay[1]:.3f}m after the old call. The replacement forward creates a new obligation.')
title('Client decision  /  post-close debt','How much each coupon costs')
para(f'The loan pays a synthetic six-month USD reset plus 150 bp. The swap receives that same reset and pays {par:.4%} fixed. The client still owes the loan spread, giving {par+spread:.4%} all-in. The cap pays the amount above 5% and costs USD {cap:.3f}m at inception. The first fixing is known when the hedge starts.')
table(['Payment','Reset','Loan','Swap receipt','Net fixed','Cap receipt','Net capped'],[[str(int(r[0])),f'{r[1]:.2%}',*[fmt(x) for x in r[2:]]] for r in cash],[20,21,24,29,24,28,26])
para(f'USD millions. Pay dates are 1 Jan 2028, 1 Jul 2028, 1 Jan 2029 and 1 Jul 2029. Total nominal interest is USD {sum(x[2] for x in cash):.3f}m floating, {sum(x[4] for x in cash):.3f}m swapped, or {sum(x[6] for x in cash)+cap:.3f}m capped including premium. This is a realized teaching path, not an expected-cost ranking. Principal is common to all three choices.',9)
chart('interest_cost',135)
h('Refinancing one year early')
para(f'Immediately after coupon two, assume the two remaining resets project at 3% and the continuous discount rate is 3%. The first remaining reset is known. The swap MTM is USD {refi[0]:.3f}m to the client. Paying this amount in absolute value closes the swap. The remaining cap can be sold for USD {refi[1]*1e6:,.0f} before costs. The loan principal and any contractual prepayment fee settle separately.')
title('Bank risk  /  portfolio design','Reading the dealer book')
para('A single acquisition moves through two stages. For a simultaneous desk snapshot, use two independent clients with identical funding terms. Client A is signing, with USD 20m each in a forward and a call. Client B has already closed, with USD 30m each in a swap and a cap. This prevents counting the same full exposure twice. The full-size client alternatives on earlier pages remain comparable.')
table(['Bank trade','Market offset at 95% of size','Residual'],[['Sell USD forward','Buy USD forward for the same maturity.','Short USD delta.'],['Write USD call','Buy a matching USD call. A desk could delta hedge and source vega separately.','Short gamma and vega on the uncovered portion.'],['Receive fixed, pay reset','Pay fixed, receive reset on a market swap.','Rate curve and hedge-index basis.'],['Sell cap','Buy same strike and caplet dates.','Unmatched volatility, fixing and index exposure.']],[40,77,55])
table(['Signed local sensitivity','Unhedged EUR','95% hedged EUR'],[[r[0],f'{r[1]*1e6:,.0f}',f'{r[2]*1e6:,.0f}'] for r in greeks],[80,46,46])
para('FX delta is the linear P&L for +0.01 EUR/USD (EUR per USD here). DV01 is signed P&L for +1 bp in the USD discount and projection curves, including FX carry. Each vega refers to +1 absolute volatility point. Gamma is half the second derivative times 0.01 squared. The first rate fixing stays locked. Cash premiums remain in their original currencies. Central differences and full revaluation use identical base positions.')
h('Credit and funding conventions')
para('OTC clients post no collateral. Enforceable netting is assumed within each separate client, with no cross-client offset. Positive MTM is the sum of positive net replacement values, excluding received premiums. Market hedges share one EUR-equivalent daily variation margin (VM) account. The model assumes immediate collateral on the change in hedge value, no initial margin and no collateral on the opening premium. Peak funding is incremental to opening balances, before client cash arrives.')
title('Bank risk  /  instant shocks','What survives the hedge')
table(['Instant shock','Unhedged','Net','Peak VM','Exposure','Loss proxy'],[[r[0],*[fmt(r[j]) for j in (1,3,4,5,7)]] for r in risk],[66,22,17,22,23,22])
para('EUR millions. All parallel USD shifts affect discounting and projection. The twist uses a front discount shift of -50 bp and projected continuous rates sloping from -50 to +50 bp relative to base. Basis affects only unfixed market-hedge forwards. The credit proxy is current positive exposure times assumed one-year default probability times 60% loss given default. It is a static diagnostic, separate from market P&L.',9)
h('Three moments in a matched forward')
f_loss=-fx(.9*S)[0]/2
para(f'At execution the USD 20m forward and its exact hedge both have zero value. Immediately after USD falls 10%, the dealer has a EUR {f_loss:.3f}m client receivable and an equal market loss. At the VM deadline it posts EUR {f_loss:.3f}m cash. If the client agrees to close out at that mark and pays the next day, the receipt covers the bridge. Rates and spot are held fixed between deadlines. The combined matched-book scenario above includes the option too.')
para('Cancellation occurs with the same FX shock as the ordinary down scenario. The agreement survives the failed deal. Before settlement the MTMs and credit exposure are identical. On full FX closeout and collection, the dealer receives the client A net replacement value, closes its market FX hedge and releases the related credit exposure. Client B continues independently. Slippage, recovery delays and physical settlement funding can increase cash needs.')
h('Verification and boundaries')
para('The Python identities test funding, carry, par swap, every coupon, expiry cost, shock aggregation and the matched hedge. Nineteen supplemental checks cover direction, model dates, implied volatility, product cash flows and credit stress. An 800-step tree checks the FX option within EUR 600. The exported workbook formula caches are compared with Python for 144 cells. Charts and report exhibits consume the same numerical arrays. No native Excel session, live data feed, legal netting opinion or historical calibration was used. Deterministic stress paths support these decisions without an estimated VaR or Expected Shortfall.')
title('Decision notes  /  illustrative mandates','Client advisory memo')
para('To the CFO of Fjord Instruments',10,True)
para(f'Secure the USD 60m draw so it is available at closing. While timing and approvals remain uncertain, buy the six-month USD call on the remaining USD {n:.0f}m. The fair premium of EUR {premium:.3f}m buys the right to walk away and preserves savings from a weaker dollar. Budget EUR {n*K+carry:.3f}m for this FX component at expiry including premium carry. If the deal is cancelled, the premium is at risk and an in-the-money option can still be monetized.')
para(f'If the amount and date become firm and upfront liquidity is scarce, the forward locks EUR {n*K:.3f}m at zero fair upfront cost. Confirm the roll budget and authority to unwind. Once debt draws, use the cap if refinancing flexibility matters and USD {cap:.3f}m is available for premium. It limits each annualized all-in coupon rate to {strike+spread:.2%} while the spread stays fixed. For debt expected to remain outstanding, the swap instead provides a predictable {par+spread:.2%} all-in rate. Confirm how future USD debt service will be funded from USD earnings or future FX purchases.')
h('Bank risk memo')
para('To the Markets risk manager and Treasury',10,True)
para(f'Offset the client directions with long USD forwards and calls, a pay-fixed swap and purchased caplets. Match currency, strike, maturity, fixing and collateral terms. At 95% coverage a 10% USD rise costs EUR {-risk[1][3]:.3f}m net. The matched down shock still requires EUR {risk[-1][4]:.3f}m of incremental collateral. Treasury should test available EUR cash and intraday credit against this call before adding positions.')
para('Review signed FX delta, gamma, both vegas, bucketed rate exposure, hedge-index spreads, positive MTM by netting set, counterparty limits and the VM payment calendar. Escalate a failed financing draw, expiry mismatch, downgrade or collateral call above available liquidity. Reprice on independent curves and executable volatility quotes before a real trade. A quoted spread earns revenue only to the extent execution and lifecycle costs permit.')
finish('Case_Report')
title('Product guide  /  foreign exchange','Forwards and exchange futures')
para(f'Fjord buys USD {n:.0f}m six months forward. The bank sells the same dollars. The fair price F = S exp[(rEUR - rUSD)T] equals {K:.6f} EUR per USD. The EUR price of USD is below spot because USD deposits earn more. Borrow euros, buy USD and invest the USD to reproduce delivery. At inception value is zero. Later, client value is USD notional times the EUR discount factor times (new forward minus contracted price).')
table(['Exhibit','Forward','USD futures teaching contract'],[['Exposure','Known acquisition payment.','A separate importer needs USD 10m.'],['Execution','Tailored zero-value OTC trade.','Long 100 synthetic contracts of USD 100,000 at 0.90 EUR per USD. Flat equal rates at inception.'],['Interim','Month three at spot 0.88 gives EUR '+fmt(midfx[0])+'m.','At 0.91 cumulative VM is EUR 0.10m. The contract resets to zero after daily settlement.'],['Settlement','At expiry 1.02, receive EUR '+fmt(fxrows[-1][2])+'m and buy the dollars for EUR 40.8m.','Close futures at 0.94 on purchase date before contract expiry. Cumulative VM is EUR 0.40m. Buy USD at 0.945 for EUR 9.45m.'],['Result','EUR '+fmt(n*K)+'m net cost.','EUR 9.05m net. Difference from EUR 9.00m comes from remaining basis. Initial margin is refundable collateral.']],[28,69,75])
para('The short futures trader pays the long side on up days through clearing. Even a profitable final hedge can need interim cash on down days. Contract size, delivery month and the exposure date create quantity and basis mismatches. An OTC forward can also have collateral terms.')
h('Interview follow-up')
para('Why would a futures hedge miss the budget? “I might close the futures before delivery. The change in its price can differ from the change in the spot rate I actually pay.”')
title('Product guide  /  options','Buying flexibility and selling a floor')
para('A USD call is a right to buy USD for euros. At expiry it is in the money when spot exceeds strike. At inception the case strike equals the forward. The Garman-Kohlhagen price is the EUR discount factor times [F N(d1) - K N(d2)] times USD notional. Here d1 = [ln(F/K) + vol squared times T / 2] / [vol times square root of T], and d2 = d1 minus vol times square root of T. N is the standard normal cumulative probability.')
para(f'The buyer pays EUR {premium:.3f}m and owns an asset of the same fair value. At month three the asset is worth EUR {midfx[1]:.3f}m in the specified market. At expiry 1.02 it pays EUR {fxrows[-1][3]:.3f}m. The seller receives premium and owes the payoff. Implied volatility is the volatility that reproduces a quoted premium with strike, maturity, forward and discount fixed. Here 10% is an assumption. Delta measures first-order spot risk, gamma the change in delta, vega volatility risk and theta sensitivity to passing time.')
h('A collar for a buyer of one unit')
para('With a one-year forward of USD 100, zero rates and 20% volatility, buy a call struck at 110 and sell a put struck at 90. Black forward pricing gives the call value. Put-call parity gives the put. The bank takes the opposite legs. The short put gives up savings below 90. Strike selection determines the net premium.')
r=examples[1]
table(['Cash or value','USD per unit'],[['Net premium paid today',fmt(r[1])],['Half-year MTM at forward 105',fmt(r[2])],['At 120, call receipt / physical spend','10.000 / 120.000'],['Net spend at 120 including premium',fmt(r[4])],['At 75, short put payment / physical spend','15.000 / 75.000'],['Net spend at 75 including premium',fmt(90+r[1])]], [120,52])
para('Follow-up: “Could I keep the low purchase price if spot falls to 75?” The sold put requires paying the difference to 90, so the collar creates a minimum effective cost.')
title('Product guide  /  interest rates','Swaps, caps and floors')
para(f'For the borrower, a pay-fixed swap exchanges each floating benchmark receipt for a fixed coupon. Discount both legs. Par fixed rate = (1 - final discount factor) / sum(accrual x discount factor) = {par:.4%}. At origination the two legs have equal PV. The bank receives fixed. At the second coupon, a 6% reset gives the client USD {cash[1][3]:.3f}m, reducing USD {cash[1][2]:.3f}m loan interest to USD {cash[1][4]:.3f}m. A fall in rates makes remaining fixed payments expensive to terminate.')
para(f'The borrower cap consists of calls on successive benchmark resets. For each unfixed caplet use Black-76 on the positive forward rate, reset time for volatility and payment date for discounting. Multiply by notional and accrual. Known fixings use discounted intrinsic value. Cap PV is USD {cap:.3f}m. At 6%, receive USD {cash[1][5]:.3f}m. At 3%, receive zero and pay the lower floating coupon. The selling bank owes each caplet payoff. The refinancing exhibit in the report shows the remaining swap and cap MTMs.')
r=examples[2]
para(f'A lender can instead buy a 3.5% floor on a USD 10m half-year coupon fixing in six months and paid in one year. Forward 4%, discount rate 4%, Black vol 30%. Use the corresponding put on the forward. Premium is USD {r[1]*1e6:,.0f}. Three months later at a 3% forward it is worth USD {r[2]*1e6:,.0f}. A 2% final reset gives USD {r[3]*1e6:,.0f} from the floor seller plus USD 100,000 loan interest. Net coupon after nominal premium is USD {r[4]*1e6:,.0f}.')
h('Cross-currency funding')
r=examples[3]
para(f'A firm borrows USD 10m for one year but needs EUR 9m. Spot is 0.90 EUR per USD. At inception it gives the bank USD 10m and takes EUR 9m. Use annual effective USD 4% and EUR 2%, no basis. At maturity the firm receives USD 10.4m from the bank and pays EUR 9.18m. The par swap has zero initial PV. An immediate move to 0.95 raises the USD leg value, giving EUR {r[2]:.3f}m MTM. At expiry spot 0.96, the swap net receipt is EUR {r[3]:.3f}m equivalent. Its USD receipt retires the USD debt, leaving EUR {r[4]:.2f}m payable.')
para('Follow-up: “Would a USD interest-rate swap solve this problem?” It changes USD coupons. Cross-currency principal exchanges also change which currency the borrower must deliver at maturity. The dealer must fund both currencies and manage cross-currency basis.')
title('Product guide  /  commodity and credit','Fuel costs and default protection')
para('A ferry operator needs 100,000 fuel units in one year. Benchmark forward and strike are USD 80, rates zero and Black volatility 25%. Choose long futures, pay-fixed/receive-index swap or a purchased call. Halfway through the year the benchmark forward is 85. At delivery the benchmark is 95 and the physical grade costs 97. Supplier and benchmark basis adds USD 0.2m to the hedged purchase.')
table(['USD millions','Initial premium','Interim value¹','Receipt¹','Net fuel cost'],[[r[0],*[fmt(x) for x in r[1:5]]] for r in examples[4:7]],[43,32,32,28,37])
para('¹ Futures columns show cumulative variation margin. The swap pays quantity times (index - fixed price) at maturity and its mark is discounted remaining settlement at the new forward. The option pays only positive differences. At a benchmark of 65 the option expires while the buyer enjoys cheaper fuel. The bank or futures short has the opposite derivative cash flows. Commodity risk also includes delivery location, grade and changes in actual fuel volume.',9)
para('Follow-up: “Why can the ferry operator still miss its budget?” Its supplier charges for a specific fuel grade at a specific port. Its hedge settles against a different published price.')
h('Credit default swap')
r=examples[-1]
para('A lender owns USD 10m face of a par zero-coupon teaching bond. Buy one-year protection. Assume a single possible credit event at maturity, 2% risk-neutral default probability, 40% recovery and a 4% continuous discount rate. Premium is payable only on survival. Equate discounted premium N x coupon x (1-q) and discounted protection N x q x (1-R). Par annual premium is 1.22449% of face. Fair initial value is zero.')
para(f'Halfway through, a conditional 5% default probability for the remaining term raises protection MTM to USD {r[2]:.3f}m. On a covered default the seller pays USD {r[3]:.1f}m and the bond recovers USD 4m. Combined proceeds are USD {r[4]:.1f}m. On survival the buyer receives face and pays USD {10*.02*.6/.98:.3f}m premium. In an actual contract qualifying credit events, auction recovery and premium accrual depend on documentation. Reference default risk and protection-seller default risk are distinct.')
para('Follow-up: “What if the protection seller also fails?” An unpaid protection claim can leave the lender exposed precisely when the reference bond loses value. Collateral and counterparty quality matter.')
finish('Product_Guide')
