import fs from 'node:fs/promises';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const dir=process.argv[2], data=JSON.parse(await fs.readFile(dir+'/layout.json'));
const wb=Workbook.create();
for(const name of ['Compare','Bank','Inputs','FX','Debt','Lifecycle','Shocks','RateStress'])wb.worksheets.add(name);
for(const [name,rows] of Object.entries(data)){
 const sh=wb.worksheets.getItem(name);
 const width=Math.max(...rows.map(r=>r.length));
 const range=sh.getRangeByIndexes(0,0,rows.length,width);
 range.format.columnWidth=18;range.format.rowHeight=19;range.setNumberFormat('0.00000;[Red](0.00000);0');
 sh.getRangeByIndexes(0,0,rows.length,1).format.columnWidth=36;
 if(['Compare','Inputs','Lifecycle'].includes(name))sh.getRangeByIndexes(0,2,rows.length,1).format.columnWidth=80;
 rows.forEach((row,i)=>row.forEach((v,j)=>{if(v===null)return;const c=sh.getCell(i,j);
 if(typeof v==='string' && v.startsWith('='))c.formulas=[[v]];else c.values=[[v]];
 if(i>0 && typeof v==='number')c.format.font={color:'#176DA3'};
 }));
 for(const i of (name==='FX'?[0,6]:[0])){let h=sh.getRangeByIndexes(i,0,1,width);h.format.fill='#12364B';h.format.font={bold:true,color:'#FFFFFF'};}
 sh.freezePanes.freezeRows(1);
}
wb.recalculate();
await (await SpreadsheetFile.exportXlsx(wb)).save(dir+'/Bank_Derivatives.xlsx');
