# Banking interview practice
먼저 질문에 영어로 한두 문장만 답하고, 면접관이 더 물어보면 숫자를 하나 붙여 보세요.

| Question | Short spoken answer | 한국어로 이해하기 |
|---|---|---|
| Why hedge only USD 40m? | “The purchase costs 100 million dollars, but the dollar loan delivers 60 million directly at closing. I only need to buy the remaining 40 million with euros.” | 대금을 어느 통화로 조달하는지 먼저 봐요. 대출이 제때 들어온다면 이미 달러로 마련한 60m까지 또 사면 과도한 hedge가 돼요. |
| Why is the dollar forward cheaper than spot here? | “We quote euros per dollar. Dollars earn the higher rate, so I can buy fewer dollars today and let the deposit grow into the amount I need.” | 지금 달러를 예금하면 이자가 더 붙어요. 만기에 1달러를 마련하기 위해 오늘 사야 하는 달러는 1달러보다 적어요. |
| Why choose an option if the forward costs zero upfront? | “A forward commits me to a price. The call buys flexibility while the acquisition is uncertain. Here that flexibility costs about one million euros upfront.” | Forward는 계약할 때 돈을 안 내도 나중에 결제해야 해요. Call은 premium을 먼저 내고, 달러가 싸지면 시장에서 더 싸게 사요. |
| What if the deal is delayed or cancelled? | “The forward survives the acquisition. I would price an unwind or a roll and identify who funds any loss at the old settlement date.” | 인수가 미뤄져도 계약 만기는 그대로예요. Roll은 기존 계약을 정산하고 새 날짜로 다시 계약하는 거예요. |
| Why does a swap fix the interest bill? | “My loan pays the index plus a spread. My swap receives the same index and pays fixed, so the two index payments cancel and I keep the loan spread.” | 대출에서 내는 변동금리를 swap에서 그대로 돌려받아요. 예를 들어 reset이 6%면 반년 대출이자 2.250m에서 swap 수취 0.588m을 빼요. 순지출은 USD 1.662m이에요. |
| What changes if the borrower refinances? | “The loan can disappear while the swap still has value. If rates have fallen, my old fixed payment is expensive and I may have to pay to exit.” | 이전에 약속한 고정금리가 새 시장금리보다 높으면 상대방에게 유리한 계약이에요. 조기 종료하려면 그 가치를 보상해 줘야 해요. |
| Why a cap rather than a swap? | “A cap protects me above the strike and lets me benefit below it. I pay a premium for that choice.” | Cap은 기준금리의 상한이에요. 이 사례에서 기준금리가 6%여도 cap이 5% 초과분을 보상하고, 대출 spread 1.5%는 회사가 내요. |
| How can a hedged bank need cash? | “The market hedge can owe variation margin today while the offsetting client receivable pays tomorrow. The position can be economically flat and still need funding.” | 같은 금액을 받을 권리와 낼 의무가 있어도 날짜가 달라요. 오늘 낼 현금은 내일 받을 돈으로 바로 대신할 수 없어요. |
| What does signed DV01 tell you? | “I bump the USD curve by one basis point and measure the change in value. I keep the first fixing locked and include the effect on FX carry.” | 1 bp는 0.01%포인트예요. 표의 음수는 금리가 조금 오르면 이 책의 은행 포지션 가치가 떨어진다는 뜻이에요. |
| What does the model miss? | “A real quote needs executable curves and volatility, actual collateral terms and a check on the financing draw. I would test those before relying on the hedge.” | 숫자를 많이 말하는 것보다 어떤 가정이 틀리면 결과가 바뀌는지 설명하는 편이 좋아요. |
