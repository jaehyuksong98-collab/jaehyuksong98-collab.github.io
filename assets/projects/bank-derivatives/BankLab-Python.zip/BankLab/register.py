"""Audit index: each metric includes units, calculation, decision and challenge."""
from model import *
from examples import rows as ex
reg=[]
def entry(name,value,unit,calc,decision,challenge):
    reg.append([name,value,unit,calc,decision,challenge])
entry('USD required',n,'USDm','Purchase less USD draw','Size FX hedge','Will debt draw in escrow on the same day?')
for name,val,unit,calc,purpose,challenge in [
('FX forward',K,'EUR per USD','Spot x exp((EUR-USD rate) x T)','Lock budget','Cross-currency basis?'),
('Forward points',(K-S)*10000,'points of 0.0001','(forward - spot) x 10000','Quote carry','Which currency is domestic?'),
('Call fair premium',premium,'EURm today','Discounted Black call x USD notional','Price flexibility','Smile and executable volatility?'),
('Illustrative quoted premium',premium+.020,'EURm today','Model premium + 0.020m','Client quote only','Execution, credit and funding costs?'),
('Carried premium',carry,'EURm at closing','Premium x exp(EUR rate x expiry)','Compare like dates','Client actual funding rate?'),
('Par swap coupon',par,'annual decimal','(1-last DF)/discounted accrual sum','Lock benchmark coupon','Are projection and discount curves different?'),
('Cap premium',cap,'USDm at closing','Sum discounted Black caplets','Budget rate protection','Reset dates and vol surface?'),
('All-in swapped',par+spread,'annual decimal','Par rate + debt spread','Budget debt service','Can credit spread change?'),
('All-in cap limit',strike+spread,'annual decimal before premium','Strike + credit spread','Limit interest expense','Does debt index match cap index?'),
('Delayed forward cost',delay[0],'EURm month 9','Replacement forward purchase minus carried old settlement','Cash needed at delayed close','Can interim losses be financed?'),
('Delayed call cost',delay[1],'EURm month 9','Replacement purchase minus carried payoff plus premium carry','Compare delayed close','Does new date remain uncertain?'),
('Swap at refi',refi[0],'USDm mark','PV of two remaining net resets','Unwind cost','Firm termination quote?'),
('Cap at refi',refi[1],'USDm mark','Intrinsic first caplet plus Black second caplet','Sale proceeds','Liquidity for remaining cap?')]:
    entry(name,val,unit,calc,purpose,challenge)
for name,vv in zip(('Forward','Call'),midfx):entry(name+' month 3 mark',vv,'EURm','Reprice using spot 0.88 and remaining quarter','Unwind at fair value','Cash now or unrealized mark?')
for row in fxrows:
    for name,ix,formula in [('Forward cost',4,'spot outlay less forward settlement'),('Call cost',5,'spot outlay less call payoff plus carried premium'),('Cancelled forward',6,'negative forward settlement'),('Cancelled call',7,'carried premium less payoff')]:
        entry(f'{name} at {row[0]}',row[ix],'EURm closing',formula,'Acquisition budget or standalone unwind','Payment still due and on which date?')
for name,j,extra in [('Floating',2,0),('Swapped',4,0),('Capped',6,cap)]:
    entry(name+' total',sum(x[j] for x in cash)+extra,'USDm nominal','Sum of realized coupons plus upfront premium if any','Cash budget over two years','Would a different rate path reverse ranking?')
for row in risk:
    for name,j,formula in [('Unhedged',1,'Repriced client book with premiums less opening value'),('Net P&L',3,'Client + market hedge change'),('Peak VM',4,'Positive part of negative market hedge change'),('Exposure',5,'Sum positive client net derivative MTMs'),('Loss proxy',7,'Exposure x assumed 1y PD x LGD')]:
        entry(row[0]+' | '+name,row[j],'EURm',formula,'Distinguish market, liquidity and credit requirements','Netting, collateral timing, PD and intraday paths?')
for name,a,b in greeks:
    for side,value in [('unhedged',a),('95% hedged',b)]:
        entry(name+' '+side,value,'EURm per stated bump','Central difference; gamma includes one half times squared move','Set sensitivity limits','Will a large move invalidate linear approximation?')
for name,start,mark,settle,econ,unit in ex:
    entry(name+' result',econ,unit,'See product_exhibits.csv and examples.py for initial, interim and final legs','Compare physical and hedge cash flows','Basis, timing or default assumption?')
save('headline_register',['measure','calculated output','unit','calculation','why it matters','interviewer challenge'],reg)
