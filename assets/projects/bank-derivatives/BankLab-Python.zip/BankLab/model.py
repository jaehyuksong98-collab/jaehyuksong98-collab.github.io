"""Synthetic acquisition lab. Run python model.py from any directory. No network."""
from math import exp, log, sqrt, erf, isclose
from pathlib import Path
import csv, json

ROOT = Path(__file__).resolve().parent
def save(name, headers, rows):
    with (ROOT / (name+'.csv')).open('w', newline='') as f:
        w = csv.writer(f)
        w.writerow(headers)
        w.writerows(rows)

def cdf(x): return (1+erf(x/sqrt(2)))/2

def black(f,k,vol,t,df):
    if t == 0 or vol == 0: return df*max(f-k,0)
    d = vol*sqrt(t)
    a = log(f/k)/d+d/2
    return df*(f*cdf(a)-k*cdf(a-d))

# Monetary units are millions throughout. Rates are decimals.
inputs = json.loads((ROOT/'assumptions.json').read_text())
S,eu,us,T,v = [inputs[k] for k in ('eur_per_usd','eur_zero','usd_zero','fx_years','fx_vol')]
debt,price,spread,strike,iv = [inputs[k] for k in ('debt_usdm','price_usdm','loan_spread','cap_strike','cap_vol')]
n = price-debt
dt = .5
K = S*exp((eu-us)*T)
def fx(s=S,t=T,r=us,vol=v):
    f = s*exp((eu-r)*t)
    df = exp(-eu*t)
    return (n*df*(f-K),n*black(f,K,vol,t,df))
premium = fx()[1]
def forwards(r,twist=0):
    return [(exp((r+twist*j/3)*dt)-1)/dt for j in range(4)]
base = forwards(us)
def rates(fs, disc, fixed, vol=iv, first=None):
    """At a reset boundary. First fixing may already be locked."""
    dfs=[exp(-disc*(i+1)*dt) for i in range(len(fs))]
    fs=list(fs)
    if first is not None: fs[0]=first
    sw=sum(debt*dt*d*(f-fixed) for f,d in zip(fs,dfs))
    cap=sum(debt*dt*black(f,strike,vol,i*dt,d) for i,(f,d) in enumerate(zip(fs,dfs)))
    return sw,cap
ann=sum(dt*exp(-us*dt*j) for j in range(1,5))
par=(1-exp(-us*2))/ann
cap=rates(base,us,par)[1]
fxrows=[]
carry=premium*exp(eu*T)
for s in [.82,.92,1.02]:
    a,b=fx(s,0)
    fxrows.append([s,n*s,a,b,n*s-a,n*s-b+carry,-a,carry-b])
save('fx_settlement',['EUR per USD','spot purchase EURm','forward receipt','call receipt','forward cost','call cost incl carried premium','cancel forward cost','cancel call cost incl carry'],fxrows)
delay_spot=.82
roll=delay_spot*exp((eu-us)*.25)
old_f,old_c=fx(delay_spot,0)
delay=[n*roll-old_f*exp(eu*.25),n*roll-old_c*exp(eu*.25)+premium*exp(eu*.75)]
path=[base[0],.06,.03,.02]
cash=[]
for j,f in enumerate(path):
    loan=debt*dt*(f+spread)
    swap=debt*dt*(f-par)
    payoff=debt*dt*max(f-strike,0)
    cash.append([j+1,f,loan,swap,loan-swap,payoff,loan-payoff])
save('interest_cashflows',['half year','fixing','loan interest USDm','swap receipt','hedged interest','cap receipt','capped interest excl premium'],cash)
refi=rates([.03,.03],.03,par)
midfx=fx(.88,.25)
# Two distinct clients/cohorts. Half of each exposure per instrument. Book in EUR.
# Rate leg is valued immediately after initial fixing. Cash premiums held in
# original currencies offset inception liability and USD translation exposure.
def book(s=S,r=us,twist=0,vol=v,ratevol=iv,basis=0):
    f,c=fx(s,T,r,vol)
    sw,cp=rates([x+basis for x in forwards(r,twist)],r,par,ratevol,first=base[0])
    return [-f/2,(premium-c)/2,-s*sw/2,s*(cap-cp)/2]
def totals(s=S,r=us,twist=0,vol=v,ratevol=iv,basis=0,coverage=.95):
    client=book(s,r,twist,vol,ratevol)
    h=[-coverage*x for x in book(s,r,twist,vol,ratevol,basis)]
    return sum(client),sum(h),sum(client)+sum(h)
def exposure(s,r,twist,vol,ratevol):
    f,c=fx(s,T,r,vol)
    sw,cp=rates(forwards(r,twist),r,par,ratevol,first=base[0])
    return max((-f-c)/2,0)+s*max((-sw-cp)/2,0)
scenarios=[
('Base',S,us,0,v,iv,0,.95,.01),
('USD +10%',S*1.1,us,0,v,iv,0,.95,.01),
('USD -10%',S*.9,us,0,v,iv,0,.95,.01),
('USD curve +100bp',S,us+.01,0,v,iv,0,.95,.01),
('USD curve -100bp',S,us-.01,0,v,iv,0,.95,.01),
('Twist front -50 / back +50bp',S,us-.005,.01,v,iv,0,.95,.01),
('FX / cap vol +3 / +5pt',S,us,0,v+.03,iv+.05,0,.95,.01),
('Hedge index +25bp',S,us,0,v,iv,.0025,.95,.01),
('Cancel before close / USD -10%',S*.9,us,0,v,iv,0,.95,.01),
('Credit weakens / USD -10%',S*.9,us,0,v,iv,0,.95,.10),
('Matched hedge / USD -10%',S*.9,us,0,v,iv,0,1,.01)]
risk=[]
for name,s,r,tw,vo,rv,b,cov,pd in scenarios:
    a,h,net=totals(s,r,tw,vo,rv,b,cov)
    e=exposure(s,r,tw,vo,rv)
    risk.append([name,a,h,net,max(-h,0),e,pd,e*pd*.6])
save('stress',['instant shock','unhedged P&L EURm','hedge P&L','net P&L','peak incremental VM funding','unsecured positive MTM','assumed 1y PD','static exposure x PD x LGD'],risk)
greeks=[]
for label,key,step,unit in [('FX delta','s',.0001,.01),('USD DV01','r',.0001,.0001),('FX vega','vol',.0001,.01),('Cap vega','ratevol',.0001,.01)]:
    x=dict(s=S,r=us,vol=v,ratevol=iv)[key]
    hi=totals(**{key:x+step})
    lo=totals(**{key:x-step})
    greeks.append([label,*[(hi[j]-lo[j])*unit/(2*step) for j in (0,2)]])
gstep=.0005
greeks.append(['FX gamma P&L for 0.01 squared',*[(totals(S+gstep)[j]-2*totals()[j]+totals(S-gstep)[j])*.5*(.01/gstep)**2 for j in (0,2)]])
save('sensitivities',['metric EURm per stated bump','unhedged','hedged 95%'],greeks)
checks=[]
def check(label,a,b,tol=1e-9):
    assert abs(a-b)<=tol,(label,a,b)
    checks.append([label,a,b,tol])
assert price>debt>0 and T==.5 and len(path)==4
check('Funding USDm',debt+n,price)
check('Forward cash and carry',K*exp(-eu*T),S*exp(-us*T))
# CRR binomial expectation via backward induction, independent of normal CDF.
steps=800
u=exp(v*sqrt(T/steps)); d=1/u
p=(exp((eu-us)*T/steps)-d)/(u-d)
tree=[max(S*u**i*d**(steps-i)-K,0) for i in range(steps+1)]
for _ in range(steps):
    tree=[exp(-eu*T/steps)*(p*y+(1-p)*x) for x,y in zip(tree,tree[1:])]
check('FX call vs 800-step tree EURm',premium,n*tree[0],.0006)
check('Par swap by discounted coupons',rates(base,us,par)[0],0)
for j,row in enumerate(cash):
    check('Fixed all-in coupon '+str(j+1),row[4],debt*dt*(par+spread))
    check('Capped coupon '+str(j+1),row[6],debt*dt*(min(row[1],strike)+spread))
for row in fxrows: check('Locked purchase '+str(row[0]),row[4],n*K)
for row in risk: check('Book P&L tie '+row[0],row[1]+row[2],row[3])
check('Perfect hedge shock',risk[-1][3],0)
assert risk[-1][4]>0
save('model_checks',['identity','computed','independent target','absolute tolerance'],checks)
summary=dict(forward=K,points=(K-S)*10000,call=premium,carry=carry,par=par,cap=cap,refi=refi,midfx=midfx,delay=delay,roll=roll,fx=fxrows,interest=cash,stress=risk,greeks=greeks,checks=len(checks))
(ROOT/'results.json').write_text(json.dumps(summary,indent=2))
if __name__=='__main__': print(f'{len(checks)} numerical checks passed')
