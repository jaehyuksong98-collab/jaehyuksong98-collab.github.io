"""Small independent teaching trades. Money in millions unless stated."""
from model import black, exp, save
rows=[]
def example(name,start,mark,settle,effect,unit):
    rows.append([name,start,mark,settle,effect,unit])
# Cash and MTM are on the corporate side. Between observations futures MTM resets.
example('Long USD futures',0,(.91-.90)*10,(.94-.90)*10,.945*10-(.94-.90)*10,'EURm; cumulative VM; spot cost net of VM')
# Synthetic one-year, zero rates, spot=forward=100. Equal call/put prices via parity.
put=lambda f,k,t: black(f,k,.2,t,1)-f+k
collar=lambda f,t: black(f,110,.2,t,1)-put(f,90,t)
example('Buyer collar',collar(100,1),collar(105,.5),120-110,120-(120-110)+collar(100,1),'USD/unit; physical cost incl premium')
floor=black(.04,.035,.3,.5,exp(-.04))-.005*exp(-.04)
example('Lender floor',10*.5*floor,10*.5*(black(.03,.035,.3,.25,exp(-.04*.75))+.005*exp(-.04*.75)),10*.5*(.035-.02),10*.5*.02+10*.5*(.035-.02)-10*.5*floor,'USDm; net coupon incl nominal premium')
# Cross currency bullet: client starts receiving EUR 9, pays USD 10.
# Coupons are annual-effective and equal each same-currency funding rate.
example('Cross currency swap',0,.95*10-9,.96*10*1.04-9*1.02,9*1.02,'EURm; mark immediately after spot move; debt + swap final EUR outlay')
# 100,000 units. Zero rates and no storage/convenience yield in flat initial curve.
qty=.1
for kind in ('futures','swap','call'):
    prem=qty*black(80,80,.25,1,1) if kind=='call' else 0
    mark=qty*black(85,80,.25,.5,1) if kind=='call' else qty*(85-80)
    payoff=qty*(95-80)
    example('Fuel '+kind,prem,mark,payoff,qty*97-payoff+prem,'USDm; physical purchase incl premium; futures mark is cumulative VM')
# One-period digital default model, terminal premium paid only on survival.
N,q,R,df=10,.02,.4,exp(-.04)
coupon=q*(1-R)/(1-q)
mark=N*exp(-.04*.5)*(.05*(1-R)-.95*coupon)
example('CDS protection',0,mark,N*(1-R),N*R+N*(1-R),'USDm; bond + protection proceeds on default')
save('product_exhibits',['client trade','premium paid or initial fair value','interim client MTM or cumulative futures VM','terminal receipt or cumulative VM','economic result per unit description','unit and meaning'],rows)
if __name__=='__main__': print(rows)
