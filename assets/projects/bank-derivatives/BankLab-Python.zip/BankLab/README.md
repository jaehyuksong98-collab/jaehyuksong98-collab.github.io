# Bank Derivatives Pricing and Risk Management Lab

Start with **Case_Report.pdf**. Page 2 follows USD 40m from signing to settlement. Page 3 follows the USD 60m loan. Pages 4–6 cover the dealer and the two decision memos. Open **Bank_Derivatives.xlsx** beside the report. **Product_Guide.pdf** expands the instruments. **Interview_Guide.md** includes Korean explanations and spoken English answers.

## Run the baseline

From this directory, use Python 3.12. The core pricing, CSV exports, audit and headline register require only the Python standard library.

```sh
python3 model.py
python3 examples.py
python3 audit.py
python3 register.py
```

To regenerate the charts and PDFs and check the shipped workbook, install Matplotlib, ReportLab, Pillow and openpyxl in your Python environment. Then run:

```sh
python3 charts.py
python3 publication.py
python3 verify.py
```

The workbook is directly usable in Excel. Blue numeric entries are inputs or scenario controls. Start on Compare, edit Inputs and read Bank for full-revaluation stresses. Debt contains simulated future resets. Lifecycle prices delay and refinancing. Shocks and RateStress expose both the client and hedge calculations. Use strictly positive rates, strike and volatilities for the lognormal worksheet formulas. Fix the schedule at four half-year periods. Report prose, standalone examples and audit expectations refer to the documented baseline.

To regenerate the workbook from code, use a Node environment with the OpenAI artifact-tool workbook runtime available as `@oai/artifact-tool` (the shipped workbook does not require it). Run these steps after model changes and before verify.py:

```sh
python3 workbook_data.py
node build_workbook.mjs .
python3 verify.py
```

**Audit trail.** assumptions.json holds the editable numerical baseline. Assumptions_and_Sources.md records dates, conventions, observed-data status, sources and open items. headline_register.csv explains each headline calculation and its interview challenge. model_checks.csv, audit_checks.csv and excel_checks.csv contain the executed checks. The three PNGs are standalone exhibits. Other CSVs and results.json retain full-precision outputs for reuse. Rounded report numbers should be compared at displayed precision.

**Reconciliation scope.** The workbook builder calculated the formulas and saved their cached values. verify.py reads those persisted results without changing them and compares 144 cells to Python at an absolute tolerance of 1e-8 in each cell's stated unit. It scans all sheets for cached errors. This checks the exported file's formula results; native Excel recalculation and trade-platform validation were not run. The binomial option check uses a separate pricing method and a EUR 600 tolerance on USD 40m notional.
