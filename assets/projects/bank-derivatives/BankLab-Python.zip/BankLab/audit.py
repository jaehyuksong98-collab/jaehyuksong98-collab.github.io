"""Additional sign, calendar, implied volatility and standalone product checks."""
from model import *
from examples import rows as ex
from datetime import date
audit=[]
def test(label,result):
    assert result,label
    audit.append([label,'PASS'])
def near(a,b): return isclose(a,b,abs_tol=1e-9)
test('Price and draw expressed in same USD units',price==100 and debt==60 and n==40)
dates=[date(2027,7,1),date(2028,1,1),date(2028,7,1),date(2029,1,1),date(2029,7,1)]
test('Four half years between closing and principal maturity',all((b.year-a.year)*12+b.month-a.month==6 for a,b in zip(dates,dates[1:])))
test('Long USD client gains when EUR price of USD rises',fxrows[-1][2]>fxrows[0][2])
test('Cap pays in exactly the above-strike period',all((row[5]>0)==(row[1]>strike) for row in cash))
test('Dealer short option gamma and vega',all(greeks[j][1]<0 for j in [2,3,4]))
test('Forward maturity replication',near(n*K,n*S*exp(-us*T)*exp(eu*T)))
test('Flat curve cap >= intrinsic',cap>=sum(debt*dt*max(f-strike,0)*exp(-us*(i+1)*dt) for i,f in enumerate(base)))
lo,hi=.001,1
for _ in range(65):
    vol=(lo+hi)/2
    if fx(vol=vol)[1]>premium:hi=vol
    else:lo=vol
test('Implied volatility recovered from synthetic call premium',near(vol,v))
test('USD future physical plus cumulative VM',near(ex[0][4],9+.005*10))
test('Collar at upper strike cost',near(ex[1][4]-ex[1][1],110))
test('Lender floor fixes minimum gross coupon',near(ex[2][4]+ex[2][1],10*.5*.035))
test('Cross currency swap settles external USD borrowing',near(.96*10*1.04-ex[3][3],ex[3][4]))
test('Fuel basis survives both linear hedges',all(near(x[4],.1*(80+2)) for x in ex[4:6]))
test('Fuel call terminal cost includes upfront premium',near(ex[6][4],ex[5][4]+ex[6][1]))
test('CDS inception protection PV equals premium PV',near(10*.02*.6*exp(-.04),10*.98*(.02*.6/.98)*exp(-.04)))
test('CDS default settlement replaces loss of principal',near(ex[-1][4],10))
test('Credit deterioration increases proxy without changing market P&L',near(risk[-2][3],risk[2][3]) and near(risk[-2][7],10*risk[2][7]))
test('Unwind and roll after financing old loss',near(delay[0],n*roll-old_f*exp(eu*.25)))
test('Refinancing loss equals fixed-minus-floating cash PV',near(-refi[0],debt*.5*(par-.03)*(exp(-.015)+exp(-.03))))
save('audit_checks',['input or calculation check','result'],audit)
print(f'{len(audit)} supplemental checks passed on the shipped baseline')
