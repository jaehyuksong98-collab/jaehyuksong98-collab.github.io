from model import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'font.size':10,'figure.facecolor':'white'})
colors=['#59798a','#066b69','#bf641b']
def finish(fig,name):
    fig.tight_layout()
    fig.savefig(ROOT/(name+'.png'),dpi=165,bbox_inches='tight')
    plt.close(fig)
x=[.75+j*.002 for j in range(176)]
fig,ax=plt.subplots(figsize=(8,3.6))
for ys,l,c in zip(([n*s for s in x],[n*K for s in x],[n*min(s,K)+carry for s in x]),('Unhedged','Forward','USD call incl. carried premium'),colors):
    ax.plot(x,ys,label=l,color=c,lw=2.4)
ax.set(xlabel='Expiry spot (EUR per USD)',ylabel='Acquisition FX cost (EURm)')
ax.legend(frameon=False);finish(fig,'fx_cost')
fig,ax=plt.subplots(figsize=(8,3.6))
for idx,l,c in zip((2,4,6),('Floating','Pay fixed','Cap, excluding upfront premium'),colors):
    ax.plot(range(1,5),[z[idx] for z in cash],label=l,color=c,marker='o')
ax.set(xticks=range(1,5),xlabel='Semiannual payment',ylabel='Interest paid (USDm)')
ax.legend(frameon=False,fontsize=8);finish(fig,'interest_cost')
fig,ax=plt.subplots(figsize=(8,4.2))
sel=[1,2,3,4,6,7,10]
for ix,l,c,offset in zip((1,3,4),('Unhedged P&L','Net P&L','Peak VM funding'),colors,(-.22,0,.22)):
    ax.barh([j+offset for j in range(len(sel))],[risk[j][ix] for j in sel],height=.20,label=l,color=c)
ax.set(yticks=range(len(sel)),yticklabels=[risk[j][0] for j in sel],xlabel='EUR millions')
ax.axvline(0,color='grey',lw=.7);ax.legend(frameon=False,fontsize=8,loc='lower left');finish(fig,'bank_stress')
