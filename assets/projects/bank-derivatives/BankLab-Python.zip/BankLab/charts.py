from model import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
plt.rcParams.update({'axes.spines.top':False,'axes.spines.right':False,'font.size':10,'figure.facecolor':'white'})
colors=['#59798a','#066b69','#bf641b']
def finish(fig,name):
    fig.tight_layout()
    fig.savefig(ROOT/(name+'.png'),dpi=165,bbox_inches='tight')
    plt.close(fig)
x=[.75+j*.002 for j in range(176)]
fig,ax=plt.subplots(figsize=(8,3.6))
for ys,l,c in zip(([n*s for s in x],[n*K for s in x],[n*min(s,K)+carry for s in x]),('Unhedged','Forward','USD call incl. carried premium'),colors):
    ax.plot(x,ys,label=l,color=c,lw=2.4)
ax.set(xlabel='Expiry spot (EUR per USD)',ylabel='Acquisition FX cost (EURm)')
ax.legend(frameon=False);finish(fig,'fx_cost')
fig,ax=plt.subplots(figsize=(8,3.6))
for idx,l,c in zip((2,4,6),('Floating','Pay fixed','Cap, excluding upfront premium'),colors):
    ax.plot(range(1,5),[z[idx] for z in cash],label=l,color=c,marker='o')
ax.set(xticks=range(1,5),xlabel='Semiannual payment',ylabel='Interest paid (USDm)')
ax.legend(frameon=False,fontsize=8);finish(fig,'interest_cost')
# Show the offsetting valuation changes and the separate funding requirement.
matched = next(row for row in risk if row[0] == 'Matched hedge / USD -10%')
unhedged, hedge, net, funding = matched[1:5]
fig = plt.figure(figsize=(7.2, 5.2), facecolor='white')
fig.text(.06, .90, 'When USD falls 10%', fontsize=25, weight='bold', color='#203850')
fig.text(.06, .82, 'Dealer stress test   /   100% matched hedge', fontsize=14, color='#485865')
rows = [('Unhedged P&L', unhedged), ('Hedge P&L', hedge),
        ('Net market P&L', net), ('Peak cash collateral', funding)]
for (label, value), y in zip(rows, [.68, .53, .38, .18]):
    color = '#ac531c' if label == 'Peak cash collateral' else '#203850'
    fig.text(.06, y, label, fontsize=16, va='center', color=color)
    sign = ('+' if value > 0 else '−') if label.endswith('P&L') else ''
    amount = f'{sign}€{abs(value):.2f}m' if abs(value) >= .005 else '€0'
    fig.text(.94, y, amount, fontsize=19, ha='right', va='center', weight='bold', color=color)
    if value:
        # Each bar gets a dedicated strip below its label and amount.
        strip = fig.add_axes([.06, y-.069, .88, .018])
        strip.set_xlim(-max(abs(unhedged), funding)*1.01, max(abs(unhedged), funding)*1.01)
        strip.barh(0, value, height=1, color=color)
        strip.set_ylim(-.5, .5)
        strip.axis('off')
fig.savefig(ROOT/'bank_stress.png', dpi=180)
plt.close(fig)
