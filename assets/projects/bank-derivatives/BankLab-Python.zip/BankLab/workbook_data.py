"""Build Excel formula layout; amounts in EUR/USD millions. Run after model."""
from model import *
grid={}
def tab(name,rows):
    grid[name]=rows
tab('Inputs',[['Synthetic assumption','Value','Unit / timing'],
['Spot',S,'EUR per USD'],['EUR zero',eu,'continuous annual'],['USD zero',us,'continuous annual'],['FX tenor',T,'years'],['FX volatility',v,'annual decimal'],['Acquisition price',price,'USDm'],['Debt drawn at closing',debt,'USDm'],['Credit spread',spread,'annual decimal'],['Cap strike',strike,'annual decimal'],['Cap volatility',iv,'annual Black decimal'],['Accrual',dt,'fixed half year'],['Hedge coverage',.95,'market hedge fraction'],['LGD',.6,'loss given default'],['Fair model only',None,'Edit blue inputs and scenario fixings. Signed cash is a receipt.']])
def opt(f,k,vol,t,df):
    z=f'({vol}*SQRT({t}))'
    d=f'(LN({f}/{k})/{z}+{z}/2)'
    return f'{df}*({f}*NORMDIST({d},0,1,TRUE)-{k}*NORMDIST({d}-{z},0,1,TRUE))'
tab('FX',[['Client pricing','Model output','Unit'],['USD to buy','=Inputs!B7-Inputs!B8','USDm'],['Forward / call strike','=Inputs!B2*EXP((Inputs!B3-Inputs!B4)*Inputs!B5)','EUR per USD'],['Points','=(B3-Inputs!B2)*10000','1 point = 0.0001'],['Call premium','=B2*'+opt('B3','B3','Inputs!B6','Inputs!B5','EXP(-Inputs!B3*Inputs!B5)'),'EURm today'],['Carried premium','=B5*EXP(Inputs!B3*Inputs!B5)','EURm at close'],['Expiry spot','Physical purchase','Forward receipt','Call receipt','Forward cost','Call incl carry','Cancel fwd cost','Cancel call cost']]+[[s,f'=A{i}*$B$2',f'=$B$2*(A{i}-$B$3)',f'=MAX(C{i},0)',f'=B{i}-C{i}',f'=B{i}-D{i}+$B$6',f'=-C{i}',f'=$B$6-D{i}'] for i,s in enumerate([.82,.92,1.02],8)])
tab('Debt',[['Period','Pay year','Discount factor','Forward rate','Caplet PV USDm','Realized fixing','Loan cost','Swap receipt','Net fixed cost','Cap receipt','Net cap cost']])
for i in range(2,6):
    t=f'(B{i}-Inputs!B12)'
    capf=f'C{i}*MAX(D{i}-Inputs!B10,0)' if i==2 else opt(f'D{i}','Inputs!B10','Inputs!B11',t,f'C{i}')
    grid['Debt'].append([i-1,f'=A{i}*Inputs!B12',f'=EXP(-Inputs!B4*B{i})','=((EXP(Inputs!B4*Inputs!B12)-1)/Inputs!B12)',f'=Inputs!B8*Inputs!B12*{capf}',f'=D{i}' if i==2 else path[i-2],f'=Inputs!B8*Inputs!B12*(F{i}+Inputs!B9)',f'=Inputs!B8*Inputs!B12*(F{i}-$B$7)',f'=G{i}-H{i}',f'=Inputs!B8*Inputs!B12*MAX(F{i}-Inputs!B10,0)',f'=G{i}-J{i}'])
grid['Debt'] += [['Total cash USDm',None,None,None,'=SUM(E2:E5)',None,*[f'=SUM({c}2:{c}5)' for c in 'GHIJK']],['Par swap rate','=(1-C5)/(Inputs!B12*SUM(C2:C5))'],['Total capped cost','=K6+E6','nominal USDm incl upfront']]
tab('Bank',[['Scenario','Desk unhedged','Hedge P&L','Net EURm','Peak VM EURm','Positive MTM','1y PD','Loss proxy EURm']])
tab('Shocks',[['Scenario','Spot factor','USD shift','Twist slope','FX vol shift','Cap vol shift','Index basis','Coverage','PD','Spot','USD zero','FX forward','Client Fwd','Client Call','Client swap USD','Client cap USD','Hedge-index swap','Hedge-index cap']])
tab('RateStress',[['Scenario','Period','Projection rate','Disc factor','Forward','Hedge forward','Swap PV','Cap PV','Hedge swap PV','Hedge cap PV']])
for i,(name,s,r,tw,vo,rv,b,cov,pd) in enumerate(scenarios,2):
    start=2+(i-2)*4
    end=start+3
    grid['Shocks'].append([name,s/S,r-us,tw,vo-v,rv-iv,b,'=Inputs!B13' if cov!=1 else 1,pd,f'=Inputs!B2*B{i}',f'=Inputs!B4+C{i}',f'=J{i}*EXP((Inputs!B3-K{i})*Inputs!B5)',f'=FX!B2*EXP(-Inputs!B3*Inputs!B5)*(L{i}-FX!B3)','=FX!B2*'+opt(f'L{i}','FX!B3',f'(Inputs!B6+E{i})','Inputs!B5','EXP(-Inputs!B3*Inputs!B5)'),*[f'=SUM(RateStress!{c}{start}:{c}{end})' for c in 'GHIJ']])
    for j in range(4):
        row=start+j
        def cp(c):
            t=f'((B{row}-1)*Inputs!B12)'
            p=f'D{row}*MAX({c}{row}-Inputs!B10,0)' if j==0 else opt(f'{c}{row}','Inputs!B10',f'(Inputs!B11+Shocks!F{i})',t,f'D{row}')
            return '=Inputs!B8*Inputs!B12*'+p
        grid['RateStress'].append([name,j+1,f'=Shocks!K{i}+Shocks!D{i}*(B{row}-1)/3',f'=EXP(-Shocks!K{i}*B{row}*Inputs!B12)','=Debt!D2' if j==0 else f'=(EXP(C{row}*Inputs!B12)-1)/Inputs!B12',f'=E{row}' if j==0 else f'=E{row}+Shocks!G{i}',f'=Inputs!B8*Inputs!B12*D{row}*(E{row}-Debt!B7)',cp('E'),f'=Inputs!B8*Inputs!B12*D{row}*(F{row}-Debt!B7)',cp('F')])
    def bookformula(a,b):
        return f'(-Shocks!M{i}+FX!B5-Shocks!N{i}+Shocks!J{i}*(Debt!E6-Shocks!{a}{i}-Shocks!{b}{i}))/2'
    grid['Bank'].append([name,'='+bookformula('O','P'),f'=-Shocks!H{i}*'+bookformula('Q','R'),f'=B{i}+C{i}',f'=MAX(-C{i},0)',f'=MAX((-Shocks!M{i}-Shocks!N{i})/2,0)+Shocks!J{i}*MAX((-Shocks!O{i}-Shocks!P{i})/2,0)',f'=Shocks!I{i}',f'=F{i}*G{i}*Inputs!B14'])
tab('Compare',[['Decision / cost','Model output','Unit / interpretation'],['Unhedged strong USD','=FX!B10','EURm at closing'],['Forward strong USD','=FX!E10','EURm at closing'],['Call strong USD','=FX!F10','EURm incl carried premium'],['Floating total','=Debt!G6','USDm sum of four coupons'],['Swap total','=Debt!I6','USDm sum of four hedged coupons'],['Cap total','=Debt!B8','USDm sum incl upfront premium'],['Cap upfront','=Debt!E6','USDm at debt inception'],['Swap and forward upfront',0,'par, fair execution'],['Read Bank next',None,'Stress measures in EURm. Two equal-weight client sleeves per cohort.']])
(ROOT/'layout.json').write_text(json.dumps(grid))
tab('Lifecycle',[['Event','Assumption / result','Unit or cash-flow timing'],
['Spot at month three',.88,'EUR per USD'],['Years left','=Inputs!B5/2','at interim mark'],['New forward','=B2*EXP((Inputs!B3-Inputs!B4)*B3)','EUR per USD'],
['Forward MTM','=FX!B2*EXP(-Inputs!B3*B3)*(B4-FX!B3)','EURm receive if positive'],['Call MTM','=FX!B2*'+opt('B4','FX!B3','Inputs!B6','B3','EXP(-Inputs!B3*B3)'),'EURm gross asset'],
['Delay length',.25,'years after original closing'],['Spot at old expiry','=FX!A8','EUR per USD'],['Replacement forward','=B8*EXP((Inputs!B3-Inputs!B4)*B7)','zero upfront'],
['Delayed cost after old forward','=FX!B2*B9-FX!C8*EXP(Inputs!B3*B7)','EURm at new closing'],['Delayed cost after old call','=FX!B2*B9-FX!D8*EXP(Inputs!B3*B7)+FX!B6*EXP(Inputs!B3*B7)','EURm at new closing'],
['Refinance forward reset',.03,'both remaining semiannual periods'],['Refinance discount rate',.03,'continuous annual'],
['Remaining swap value','=Inputs!B8*Inputs!B12*(B12-Debt!B7)*(EXP(-B13*Inputs!B12)+EXP(-B13*2*Inputs!B12))','USDm client receipt if positive'],
['Remaining cap value','=Inputs!B8*Inputs!B12*(EXP(-B13*Inputs!B12)*MAX(B12-Inputs!B10,0)+'+opt('B12','Inputs!B10','Inputs!B11','Inputs!B12','EXP(-B13*2*Inputs!B12)')+')','USDm sale value']])
(ROOT/'layout.json').write_text(json.dumps(grid))
