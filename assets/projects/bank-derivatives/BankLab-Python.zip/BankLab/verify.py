"""Reconcile exported XLSX formula caches against independent Python pricing."""
from model import *
import openpyxl
wb=openpyxl.load_workbook(ROOT/'Bank_Derivatives.xlsx',data_only=True)
formula_wb=openpyxl.load_workbook(ROOT/'Bank_Derivatives.xlsx',data_only=False)
ties=[]
def tie(sheet,cell,expected):
    value=wb[sheet][cell].value
    assert isinstance(value,(int,float)) and abs(expected-value)<1e-8,(sheet,cell,value,expected)
    ties.append([sheet,cell,value,expected,value-expected])
for c,num in zip(('B2','B3','B4','B5','B6'),(n,K,(K-S)*10000,premium,carry)): tie('FX',c,num)
for i,row in enumerate(fxrows,8):
    for col,val in zip('BCDEFGH',row[1:]):tie('FX',col+str(i),val)
for i,row in enumerate(cash,2):
    for col,val in zip('FGHIJK',row[1:]):tie('Debt',col+str(i),val)
for cell,val in [('E6',cap),('B7',par),('B8',sum(x[6] for x in cash)+cap)]:tie('Debt',cell,val)
for i,row in enumerate(risk,2):
    for col,val in zip('BCDEFGH',row[1:]):tie('Bank',col+str(i),val)
for i,num in enumerate([fxrows[-1][1],fxrows[-1][4],fxrows[-1][5],sum(x[2] for x in cash),sum(x[4] for x in cash),sum(x[6] for x in cash)+cap,cap],2):tie('Compare','B'+str(i),num)
for cell,val in zip(('B5','B6','B9','B10','B11','B14','B15'),[*midfx,roll,*delay,*refi]):
    tie('Lifecycle',cell,val)
for sheet in wb:
    for row in sheet:
        assert all(c.data_type!='e' for c in row)
assert formula_wb['FX']['B5'].data_type=='f'
save('excel_checks',['sheet','cell','cached Excel formula','Python','difference'],ties)
print(f'{len(ties)} workbook ties passed; maximum absolute error {max(abs(x[-1]) for x in ties):.3g}')
